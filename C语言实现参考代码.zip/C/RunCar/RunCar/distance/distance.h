#ifndef __DISTANCE_H
#define __DISTANCE_H

#include <wiringPi.h>
#include <stdio.h>
#include <sys/time.h>

//定义超声波引脚
//Num 0: 前
//Num 1: 左
//Num 2: 右
#define Dis_Front	0
#define Dis_Left	1
#define Dis_Right	2
//避障
#define LEFT	11
#define RIGHT	10

//变量定义
extern const unsigned int Trig[3];
extern const unsigned int Echo[3];
extern float dis[3];

//函数定义
void ultraInit(void);   //初始化超声波
void HW_Init(void);     //初始化避障
float disMeasure(unsigned int num);//距离检测
void Get_dis(void);     //距离更新

#endif
