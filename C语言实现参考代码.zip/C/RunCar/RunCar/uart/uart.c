#include "uart.h"

unsigned char UartBuff[256];
int fd;

void Open_serial(int buad)
{
    if((fd = serialOpen ("/dev/ttyS0",buad))<0)
    {
        printf("serial err\n");
    }
    printf("serial OK\n");
    serialPrintf(fd,"serial OK\r\n");
}

void Check_Command(void)
{
    if (serialDataAvail(fd) > 0)
    {
        UartBuff[0]=serialGetchar(fd);
        switch(UartBuff[0])
        {
        case 0x01:
            if(!taskflag)
            {
                taskflag = 1;
                serialPuts(fd,"\r\nDistance Test\r\n");
            }
            break;
        case 0x02:
            if(!taskflag)
            {
                taskflag = 2;
                serialPuts(fd,"\r\nInfrared Test\r\n");
            }
            break;
        case 0x03:
            if(!taskflag)
            {
                taskflag = 3;
                serialPuts(fd,"\r\nRemote Mode\r\n");
            }
            break;
        case 0x04:
            if(!taskflag)
            {
                taskflag = 4;
                serialPuts(fd,"\r\nAvoid Mode\r\n");
            }
            break;
        case 0x00:
            taskflag = 0;
            serialPuts(fd,"\r\nClose Task\r\n");
            stop(100);
            break;
        default:
            if(taskflag == 3)
            {
                if(UartBuff[0]>0xF0) motormode = UartBuff[0]&0x0F;
            }
            else
            {
                taskflag = 0;
                serialPuts(fd,"\r\nClose Task\r\n");
                stop(100);
            }

        }
    }

}
