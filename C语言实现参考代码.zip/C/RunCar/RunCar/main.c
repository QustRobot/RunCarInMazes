#include "main.h"

void Init()
{
    if(wiringPiSetup() == -1){ //when initialize wiring failed,print messageto screen
        printf("setup wiringPi failed !");
        return 1;
     }

     ultraInit();
     HW_Init();
     Motor_Init();
     Open_serial(115200);

     printf("Init OK\n");
     serialPrintf(fd,"Init OK\r\n");

}

int main()
{    
    Init();
    stop(100);
    while(1)
    {
        Task_Run();
        Check_Command();
    }
    return 0;
}
