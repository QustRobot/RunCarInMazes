#ifndef __MOTOR_H
#define __MOTOR_H

#include <wiringPi.h>
#include <stdlib.h>
#include <math.h>
#include <softPwm.h>
#include <unistd.h>
#include <errno.h>
#include <string.h>
#include <sys/types.h>
#include <time.h>
#include <wiringPi.h>

//电机引脚
// IN0 -> 1
// IN1 -> 4
// IN2 -> 5
// IN3 -> 6
//[0 1 | 2 3]
// 右    左
//前：10
//后：01
//停：00
#define M_IN0	1
#define M_IN1	4
#define M_IN2	5
#define M_IN3	6

#define MAX_PWM 500
#define MIN_PWM 0

extern int speed;
extern int turn;

void Motor_Init(void);              //初始化电机
void run(int value_l, int value_r); //电机转动
void stop(int time);                //停止电机

#endif
