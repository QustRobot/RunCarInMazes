#include "task.h"

int taskflag = 0;
int nowtask = 0;
int motormode = 0;

//测试超声波
void Test_dis(void)
{
    Get_dis();
    serialPrintf(fd,"front = %0.2f cm\t left = %0.2f cm\t right = %0.2f cm\t\r\n",dis[Dis_Front],dis[Dis_Left],dis[Dis_Right]);
    delay(500);
}

//测试红外
void Test_HW(void)
{
    int SL, SR;
    //有信号为LOW  没有信号为HIGH
    SR = digitalRead(RIGHT);//
    SL = digitalRead(LEFT);//

    serialPrintf(fd,"Left:%d,Right:%d\r\n",SL,SR);
    delay(500);
}

//走迷宫
void Car_Avoid(void)
{
    float temp;
    int SL, SR;
    //有信号为LOW  没有信号为HIGH
    SR = digitalRead(RIGHT);//
    SL = digitalRead(LEFT);//

    Get_dis();
    if(dis[Dis_Front] < 18.0)
    {
        Get_dis();
        temp = dis[Dis_Left]-dis[Dis_Right];
        printf("%0.2f\n",temp);
        if(abs(temp) > 10.0)
        {
            stop(100);
            if(temp > 0)
            {
                run(-350,350);
            }
            else
            {
                run(350,-350);
            }
            delay(350);
        }
        else
        {
            run(400,400);
        }
    }
    else
    {
        printf("%d,%d\n",SR,SL);
        if(SL == HIGH && SR == HIGH)
        {
            run(500,500);
        }
        else
        {
            run(400*SR, 400*SL);
        }

    }
}


void Test_Motor()
{
    switch(motormode)
    {
    case 0x0f:stop(100);                                        break;
    case 0x01:run(speed,speed);                                 break;
    case 0x02:run(-1*speed,-1*speed);                           break;
    case 0x03:run(-1*turn,turn);                                break;
    case 0x04:run(turn,-1*turn);                                break;
    case 0x05:if(speed<=MAX_PWM-10) speed+=10;motormode=0x00;   break;
    case 0x06:if(speed>10) speed-=10;motormode=0x00;            break;
    case 0x07:if(turn<=MAX_PWM-10) turn+=10;motormode=0x00;     break;
    case 0x08:if(turn>10) turn-=10;motormode=0x00;              break;
    case 0x09:stop(100);                                        break;
    case 0x00:serialPrintf(fd,"speed:%d,turn:%d\n",speed,turn);motormode=0x0f;break;
    default:stop(100);
    }


}



void Task_Run(void)
{
    switch(taskflag)
    {
    case 0x01:
        Test_dis();
        break;
    case 0x02:
        Test_HW();
        break;
    case 0x03:
        Test_Motor();
        break;
    case 0x04:
        Car_Avoid();
        break;
    default:
        stop(100);
        //No Task
    }

}
