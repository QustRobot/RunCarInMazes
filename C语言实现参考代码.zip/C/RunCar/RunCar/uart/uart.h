#ifndef __UART_H
#define __UART_H
/*
 *
 * extern int   serialOpen      (const char *device, const int baud) ;
 * extern void  serialClose     (const int fd) ;
 * extern void  serialFlush     (const int fd) ;
 * extern void  serialPutchar   (const int fd, const unsigned char c) ;
 * extern void  serialPuts      (const int fd, const char *s) ;
 * extern void  serialPrintf    (const int fd, const char *message, ...) ;
 * extern int   serialDataAvail (const int fd) ;
 * extern int   serialGetchar   (const int fd) ;
 *
*/

#include <stdio.h>
#include <wiringSerial.h>
#include "task/task.h"

extern unsigned char UartBuff[256];
extern int fd;

void Open_serial(int buad);     //打开串口


#endif
