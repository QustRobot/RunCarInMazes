#ifndef __TASK_H
#define __TASK_H

#include "distance/distance.h"
#include "motor/motor.h"
#include "uart/uart.h"

int taskflag;           //任务标记
int taskbuf;            //任务缓冲
int motormode;          //电机状态

//任务：
// 0 停止全部
// 1 测试超声波
// 2 测试红外
// 3 测试电机 -- 遥控
// 4 走迷宫

//电机:
//
//
//
//

void Test_dis(void);    //测试超声波
void Test_HW(void);     //测试红外
void Test_Motor(void);  //测试电机
void Car_Avoid(void);   //走迷宫
void Task_Run(void);    //任务运行

#endif
