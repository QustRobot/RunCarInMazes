#include "distance.h"

const unsigned int Trig[3] = {28,24,21};
const unsigned int Echo[3] = {29,25,22};
float dis[3] = {0};

//初始化超声波
void ultraInit(void)
{
    int i;
    for(i = 0; i < 3; i++)
    {
        pinMode(Echo[i], INPUT);
        pinMode(Trig[i], OUTPUT);
    }

}

//初始化避障
void HW_Init(void)
{
    pinMode(LEFT, INPUT);
    pinMode(RIGHT, INPUT);
}

//距离检测
float disMeasure(unsigned int num)
{
  struct timeval tv1;
  struct timeval tv2;
  long start, stop;
  float dis;

  if(num < 0 || num > 3)
      return 0;

  digitalWrite(Trig[num], LOW);
  delayMicroseconds(2);

  digitalWrite(Trig[num], HIGH);
  delayMicroseconds(10);	  //发出超声波脉冲
  digitalWrite(Trig[num], LOW);

  while(!(digitalRead(Echo[num]) == 1));
  gettimeofday(&tv1, NULL);		   //获取当前时间

  while(!(digitalRead(Echo[num]) == 0));
  gettimeofday(&tv2, NULL);		   //获取当前时间

  start = tv1.tv_sec * 1000000 + tv1.tv_usec;   //微秒级的时间
  stop  = tv2.tv_sec * 1000000 + tv2.tv_usec;

  dis = (float)(stop - start) / 1000000 * 34000 / 2;  //求出距离

  return dis;
}

//更新距离
void Get_dis(void)
{
    unsigned int n;
    for(n = 0; n < 3; n++)
    {
        dis[n] = disMeasure(n);
    }
}
