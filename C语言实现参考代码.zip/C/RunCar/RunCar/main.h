#ifndef __MAIN_H
#define __MAIN_H

#include <stdio.h>
#include <wiringSerial.h>
#include "task/task.h"
#include "uart/uart.h"

void Init(void);

#endif
