#include "motor.h"

int speed = 350;
int turn = 300;

//初始化电机
void Motor_Init(void)
{
    pinMode(M_IN0, OUTPUT);	//IN1
    pinMode(M_IN1, OUTPUT);	//IN2
    pinMode(M_IN2, OUTPUT);	//IN3
    pinMode(M_IN3, OUTPUT);	//IN4
    softPwmCreate(M_IN0,1,500);
    softPwmCreate(M_IN1,1,500);
    softPwmCreate(M_IN2,1,500);
    softPwmCreate(M_IN3,1,500);
}

//电机转动
void run(int value_l, int value_r)
{
    int v1, v2, v3, v4;

    if(value_l>MAX_PWM) value_l = MAX_PWM;
    if(value_r>MAX_PWM) value_r = MAX_PWM;
    if(value_l<-1*MAX_PWM) value_l = -1*MAX_PWM;
    if(value_r<-1*MAX_PWM) value_r = -1*MAX_PWM;

    v1 = value_l>0 ? value_l : 0;
    v2 = value_l<0 ? -value_l : 0;
    v3 = value_r>0 ? value_r : 0;
    v4 = value_r<0 ? -value_r : 0;

    softPwmWrite(M_IN0,v1);
    softPwmWrite(M_IN1,v2);
    softPwmWrite(M_IN2,v3);
    softPwmWrite(M_IN3,v4);

    delay(10);
}
//停止电机
void stop(int time)
{
    softPwmWrite(M_IN0,0);
    softPwmWrite(M_IN1,0);
    softPwmWrite(M_IN2,0);
    softPwmWrite(M_IN3,0);
    delay(time);
}
